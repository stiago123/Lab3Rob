%%
% CAS Design
%
% This function shows the CAS design process for lateral and
% longitudinal models of an UAV (Minnesota). In order to run this demo, it
% is necessary to install the SAS_Simulation files first. If it is the
% case, this script runs the SAS example or looks for the saved results,
% and uses them to design the CAS systems.
%
% In the first step, a pitch-attitude hold is designed by using the
% longitudinal model with SAS system already incorporated. Two linear
% controllers are designed and compared (linear simulation), a proportional
% controller and a PI controller with lead compensation. 
%
% Then, the lateral model is used to design a roll angle hold. Again,
% propotional and PI controller are desgined and compared.
%
% Finally, the PI controller for pitch and the PI controller for roll angle 
% are tested in a non-linear simulation.
% 
% David Herrera UNAL 
% 2013


% Load models
clc
if exist('../SAS_Simulation','dir')==0
    disp('Please install ths SAS_simulation directory')
    disp('End')
    return
end
cd ../SAS_Simulation
if exist('SAS_system.mat','file')==0 
   disp('SAS_simulation directory is installed, but there is no SAS file') 
   disp('Please run SAS_dampers, it is not necessary to save any data')
   reply = input('Do you want to run SAS_dampers? Y/N [Y]: ', 's');
   if isempty(reply)
    reply = 'Y';
   end
   if reply=='Y' || reply=='y'
       SAS_dampers
   else
       clc
       disp('Please run SAS_dampers and save the results')
       disp('End')
       return
   end
else
    cd ../NL_Sim
    setup
    cd ../SAS_Simulation
    load SAS_system.mat
end
    
cd ../CAS_Simulation
clc
close all

%% Longitudinal system

% Pitch-Attitude Hold design

disp('To start, we are going to design a Pitch-Attitude Hold system')

% System definition
aa=aug_longmod.a; ba=aug_longmod.b(:,1); ca=aug_longmod.c(3:4,:); 
elevtoqtheta=ss(aa,ba,ca,zeros(2,1));

disp('This is the longitudinal system with elevator as input')
disp('and q and theta as outputs (actuator dynamics already incorporated):')
evalc('elevtoqtheta')

disp('Press any key to continue')
pause

%Root-Locus
rlocus(elevtoqtheta(2))
title('Elevator to $\alpha$','interpreter','latex')
grid
figure
rlocus(utoq)
title('Elevator to q')
grid

clc
disp('Root-locus for elevator to alpha and elevator to q are shown')
disp('Press any key to continue')
pause

close all
clc
rlocus(utoq_fil)
disp('Remember the augmented longitudinal model:')
evalc('utoq_fil')
disp('with pitch-rate gain')
evalc('k_opt')
disp('Press any key to continue')
pause

% Controller design
aa=utoq_fil.a; ba=elevtoqtheta.b; ca=elevtoqtheta.c(2,:);
clc
disp('The augmented system is going to be used to design the controller')
k_theta=-5; % Choose this value
disp('The controller is given by')
evalc('k_theta')
rtotheta=feedback(k_theta*ss(aa,ba,ca,0),1);
disp('Press any key to continue')
pause

clc
disp('After chosing the feedback gain, this is the resulting u to q system:')
evalc('rtotheta')
rlocus(rtotheta)
grid
disp('Root-locus is shown')
disp('Press any key to continue')
pause
close all

clc
disp('Watch the linear simulation')
step(rtotheta,3.5)
disp('Press any key to continue')
pause

clc
close all
k_theta=zpk(tf([-3.7065  -18.2950  -22.8910],[1 5 0]));%%%%%%
disp('Last controller shows slow system response,')
disp('overshoot and steady state error different from 0')
disp('A new controller is given by:')
evalc('k_theta')
disp('A PI controller + lead compensator')
rtotheta=feedback(k_theta*ss(aa,ba,ca,0),1);
disp('Press any key to continue')
pause

clc
disp('This is the resulting r to alpha system:')
evalc('rtotheta')
rlocus(k_theta*ss(aa,ba,ca,0))
grid
figure
margin(k_theta*ss(aa,ba,ca,0))
grid
disp('Root-locus and bode plots are shown')
disp('Press any key to continue')
pause
close all

clc
disp('Watch the linear simulation')
step(rtotheta)
disp('Press any key to continue')
pause
close all

% Removing the PI zero
clc
disp('If we remove the zero from the PI controller we get')
disp('the response shown in the figure')
[num,den]=tfdata(k_theta,'v');
[r,p,k]=residue(num,den);
ki=tf(r(2),[1 0]);
kc=tf(r(1),[1 -p(1)]);
k_theta1=ki+kc;
temp=feedback(ss(aa,ba,ca,0),k);
rtotheta1=feedback(k_theta1*temp,1);
step(rtotheta,rtotheta1)
legend('Original PI','Closed-loop zero removed')
disp('Press any key to continue')
pause

%% Lateral-Directional Model

% Roll-Angle-Hold

clc 
close all
disp('Now, we are going to design a Roll-Angle Hold system')

% System definition
actuator= tf(50.3855,[1 50.3855]); % linear
new_aug_latmod=series(actuator,modred(latmod([2 4],1),5,'Truncate'));
disp('This is the lateral-directional system with aileron as input')
disp('and p and phi as outputs (actuator dynamics already incorporated')
disp('and psi state removed:')
evalc('new_aug_latmod')
disp('Press any key to continue')
pause

clc
aug_latmod_kp=feedback(kp*new_aug_latmod,[1 0]);
disp('The kp fouded for SAS system for p is going to be used')
disp('This is the augmented system:')
evalc('aug_latmod_kp')
disp('Press any key to continue')
pause

rlocus(aug_latmod_kp(2))
grid
disp('Root-Locus for aileron to phi is shown')
disp('Press any key to continue')
pause

clc
close all
k_phi=-2.0905;
disp('The selected controller is given by')
evalc('k_phi')
phi_cl=feedback(k_phi*aug_latmod_kp,[0 1]);
disp('The resulting closed loop system is')
evalc('phi_cl')
disp('Press any key to continue')
pause

clc
disp('Root-Locus and linear simulation are shown')
rlocus(k_phi*aug_latmod_kp(2))
grid
figure
step(phi_cl(2),3)
disp('Press any key to continue')
pause

% PI controller

clc
close all
%k_phi_pi=tf([-2.3487 -1.7048],[1 0]);
%k_phi_pi=tf([-2.9263   -2.1240],[1 0]);
%k_phi_pi=tf([ -4.0626 -2.1240],[1 0]);
%k_phi_pi=tf([-1.5966   -0.0784],[1 0]);
k_phi_pi=tf([-2.1459   -0.1054],[1 0]);
disp('For zero steady state error we design PI contrroller')
evalc('k_phi_pi')
disp('Press any key to continue')
pause

clc
disp('Root-Locus and linear simulation are shown')
rlocus(k_phi_pi*aug_latmod_kp(2))
grid
figure
phi_cl2=feedback(k_phi_pi*aug_latmod_kp,[0 1]);
step(phi_cl2(2))
disp('Press any key to continue')
pause

% Non linear simulation
clc
close all
disp('Non linear simulation')
sim('UAV_NL_CAS')
disp('Done')
disp('Controller responses are shown')
t=0:0.02:25;
plot(t,theta_cmd,'b','LineWidth',2)
hold
plot(t,theta_med,'g','LineWidth',2)
legend('\theta cmd','\theta')
figure
plot(t,phi_cmd,'b','LineWidth',2)
hold
plot(t,phi_med,'g','LineWidth',2)
legend('\phi cmd','\phi')
grid
disp('END')