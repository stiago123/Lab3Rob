%%
% SAS Pitch Rate and Yaw Damper
%
% This function shows the SAS dampers design process for lateral and
% longitudinal models of an UAV (Minnesota). 
% 
% In the first step, a SAS system is designed for the UAV longitudinal
% model. Due to stable longitudinal poles, only pitch rate feedback is
% used. Root-Locus and Bode are shown for elevator to alpha system.
% Then, the pitch feedback gain is found through iteration, looking for
% higher damping. Impulse linear and doublet non linear (elevator input) 
% simuluations are shown.
% 
% After, the procedure is repeated to find the roll an yaw rate gains. The
% roll rate gain is calculated first. Impulse linear and non linear (rudder
% input first, ailerons input after) simulations are shown.
%
% David Herrera UNAL 
% 2012
% Rev. 2013

% Load models
% cd ../NL_Sim
% setup
cd ../SAS_Simulation
clc

%% Longitudinal system

close all
elevtoalpha=tf(longmod(2,1));
disp('')
disp('The elevator to alpha system is')
evalc('elevtoalpha')
disp('Longitudinal Poles:')
disp('')
damp(elevtoalpha)
% Root-Locus
figure
rlocus(elevtoalpha)
grid on
figure
% Bode
bode(elevtoalpha)
grid on
disp('')
disp('Root-Locus and Bode diagrams are shown (Elevator to alpha system)')
disp('')
disp('This system is stable, so only pitch rate feedback is needed')
disp('')
disp('Press any key to continue...')

pause
close all
clc

% Augmented System

disp('Now, the augmented system, long. model + actuator, is defined')
actuator= tf(50.3855,[1 50.3855]); % linear
aug_longmod=series(actuator,longmod);

disp('')
disp('The complete system is:')
evalc('aug_longmod')

aa=aug_longmod.a; ba=aug_longmod.b; ca=aug_longmod.c; 
% Root-Locus
rlocus(aa,ba(:,1),ca(3,:),0)
grid on
figure
% Bode
bode(aa,ba(:,1),ca(3,:),0)
grid on
disp('')
disp('Root-Locus and Bode diagrams are shown (Elevator to q system)')
disp('')
% Poles
utoq=tf(ss(aa,ba(:,1),ca(3,:),0));
disp('The Elevator to q system is:')
evalc('utoq')
disp('The Augmented System Poles are:')
damp(utoq)

disp('Press any key to continue...')
pause
clc

%% Pitch-SAS Design

disp('Now, we iterate over pitch rate feedback gain, in order to increase damping')
disp('')
disp('Watch the root-locus evolution as we change the feedback gain...')
disp('')
close all
zeta_opt=0;
k_opt=0;
for t=-100:180
acl=aa-ba(:,1)*t*0.001*ca(3,:);
utoq_fil=ss(acl,ba(:,1),ca(3,:),0);
rlocus(utoq_fil)
axis([-15 15 -15 15])
grid on
polos=pole(utoq_fil);
if find(real(pole(utoq_fil))>0)
    disp('UNSTABLE')
else
    zeta=cos(atan(imag(polos(2))/real(polos(2))));
    if zeta > zeta_opt && zeta < 1
        k_opt=0.001*t;
        zeta_opt=zeta;
    end
    ct=abs(4.5/real(polos(2)));
    wn=abs(real(polos(2))/zeta);
end
pause(0.01)
end

close all

acl=aa-ba(:,1)*k_opt*ca(3,:);
utoq_fil=ss(acl,ba(:,1),ca(3,:),0);
figure
rlocus(utoq_fil)
grid on
figure
bode(utoq_fil)
grid on
clc
disp('Root-Locus and Bode diagrams are shown (Elevator to q system with feedback)')
disp('')
disp('These are the optimal values')
disp('')
disp(['zeta: ' num2str(zeta_opt)])
disp(['K_q ' num2str(k_opt)])
disp('Press any key to continue...')
pause
close all
clc

% simulation

disp('Non Linear simulation is being made...')
disp('We want to compare Longitudinal response with and with out SAS')

roll_input=0;
pitch_input=1;
yaw_input=0;
kp=0;
kr=0;
washout_filter=0;
sim('UAV_NL_NAug')
sim('UAV_NL_Aug')
stime=0:12.5/(length(q)-1):12.5;
figure
plot(stime,q,'LineWidth',2)
hold
plot(stime,q_aug,'r','LineWidth',2)
grid on
legend('Long. Model','Aug. Long. Model')
title('q [deg/sec]')
figure
plot(stime,theta,'LineWidth',2)
hold
plot(stime,theta_aug,'r','LineWidth',2)
grid on
legend('Long. Model','Aug. Long. Model')
title('$\theta$ [deg]','interpreter','latex')

disp('Plots show the system response with SAS on (Aug. Model) and with SAS off')
disp('Press any key to continue...')
pause
clc
close all

%% SAS Roll-Yaw Rate
% Lateral Model 

disp('Now, it is time for the lateral model')
disp('')
% Transfer function definition

ailtop=tf(latmod(2,1));
ailtor=tf(latmod(3,1));
rudtop=tf(latmod(2,2));
rudtor=tf(latmod(3,2));
disp('Roll-Yaw modes:')
damp(latmod)

disp('')
disp('This system is unstable')
disp('In order to apply the SAS design procedure, we remove the psi state')

disp('')
disp('Press any key to continue...')
pause
clc
disp('Now, we define the augmented system:')
disp('Actuator + Model + Washout Filter')

% Augmented system
ryactuator=-[ss(actuator) 0;0 ss(actuator)];
aug_latmod=series(ryactuator,modred(latmod([2 3],:),5,'Truncate'));
% wash-out filter
tau_wo=0.33;
washout_filter=tf([1 0],[tau_wo 1]);
% system with filter
complete_filter=[ss(1) 0; 0 ss(washout_filter)];
aug_latmod_wo=series(aug_latmod,complete_filter);

disp('')
disp('This is the complete model:')
disp('')
evalc('aug_latmod_wo')
disp('')
disp('Press any key to continue...')
pause
% Roll classical design

clc
disp('Now, we iterate over roll rate feedback gain, in order to increase damping')
disp('')
disp('Watch the root-locus evolution as we change the feedback gain...')
disp('')

close all
clear z_opt sys_opt zeta_opt kr kp
indice=1;
for z=-0.2:0.001:0.2
    acl=aug_latmod_wo.a-aug_latmod_wo.b*[z 0; 0 0]*aug_latmod_wo.c;
    roll_s=ss(acl,aug_latmod_wo.b(:,1),aug_latmod_wo.c(1,:),0);
    rlocus(roll_s)
    [Wn,zeta,P]=damp(roll_s);
    if min(size(find(real(P)>0)))==0
        z_opt(indice)=z;
        indice=indice+1;
    end
    pause(0.01)
    %disp(z)
end

for z=1:max(size(z_opt))
    roll_s=feedback(aug_latmod_wo,[z_opt(z) 0; 0 0]);
    [Wn,zeta,P]=damp(roll_s);
    if z==1
        zeta_opt=min(abs(zeta));
        sys_opt=feedback(aug_latmod_wo,[z_opt(z) 0; 0 0]);
        kp=z_opt(z);
    end
    if min(abs(zeta)) > zeta_opt
        zeta_opt=min(abs(zeta));
        sys_opt=feedback(aug_latmod_wo,[z_opt(z) 0;0 0]);
        kp=z_opt(z);
    end
end

clc
close all
kr=0;
disp('')
disp('The optimal feedback gain is:')
disp(kp)
disp('Plots show impulse response (linear simulation)')
impulse(sys_opt,aug_latmod,5)
grid
legend('SAS on','SAS off')
figure
impulse(sys_opt(1,1),aug_latmod(1,1),5)
legend('SAS on','SAS off')
grid

disp('')
disp('Press any key to continue...')
pause

disp('')
disp('Now, the non linear simulation...')
disp('Please wait')
close all
roll_input=1;
pitch_input=0;
yaw_input=1;
sim('UAV_NL_NAug')
sim('UAV_NL_Aug')
stime=0:40/(length(p)-1):40;
plot(stime,p,'LineWidth',2)
hold
plot(stime,p_aug,'r','LineWidth',2)
grid on
legend('Lat. Model','Aug. Lat. Model')
title('p [deg/sec]')
figure
plot(stime,phi,'LineWidth',2)
hold
plot(stime,phi_aug,'r','LineWidth',2)
grid on
legend('Lat. Model','Aug. Lat. Model')
title('$\phi$ [deg]','interpreter','latex')

disp('')
disp('Press any key to continue...')
pause
% Yaw classical design

clc
disp('At this moment, we want to repeat the procedure to find the yaw feedback gain')
close all
clear z_opt sys_opt zeta_opt kr
indice=1;
for z=-1:0.001:1
    yaw_s=feedback(aug_latmod_wo,[kp 0;0 z]);
    [Wn,zeta,P]=damp(yaw_s);
    if max(size(find(real(P)>=-0.01)))==1
        z_opt(indice)=z;
        indice=indice+1;
    end
end

for z=1:max(size(z_opt))
    yaw_s=feedback(aug_latmod_wo,[kp 0; 0 z]);
    [Wn,zeta,P]=damp(yaw_s);
    rlocus(yaw_s(2,2))
    %min(abs(zeta))
    if z==1
        zeta_opt=min(abs(zeta));
        sys_opt=feedback(aug_latmod_wo,[kp 0; 0 z]);
        kr=z_opt(z);
    end
    if min(abs(zeta)) > zeta_opt %&& min(abs(zeta)) < 0.9
        zeta_opt=min(abs(zeta));
        sys_opt=feedback(aug_latmod_wo,[kp 0; 0 z]);
        kr=z_opt(z);
    end
    pause(0.01)
end

close all
disp('')
disp('This is the optimal value:')
disp(kr)
disp('')
disp('Plots show impulse response (linear simulation)')
impulse(sys_opt,aug_latmod,5)
grid
legend('SAS on','SAS off')
figure
impulse(sys_opt(2,2),aug_latmod(2,2),5)
legend('SAS on','SAS off')
grid

disp('')
disp('Press any key to continue...')
pause

clc
disp('Finally, the non linear simulation with SAS system (lateral model) for Yaw and Roll rates')
close all
roll_input=1;
pitch_input=0;
yaw_input=1;
sim('UAV_NL_NAug')
sim('UAV_NL_Aug')
stime=0:40/(length(p)-1):40;
plot(stime,r,'LineWidth',2)
hold
plot(stime,r_aug,'r','LineWidth',2)
grid on
legend('Lat. Model','Aug. Lat. Model')
title('r [deg/sec]')
figure
plot(stime,psi,'LineWidth',2)
hold
plot(stime,psi_aug,'r','LineWidth',2)
grid on
legend('Lat. Model','Aug. Lat. Model')
title('$\psi$ [deg]','interpreter','latex')
figure
plot(stime,p,'LineWidth',2)
hold
plot(stime,p_aug,'r','LineWidth',2)
grid on
legend('Lat. Model','Aug. Lat. Model')
title('p [deg/sec]')
figure
plot(stime,phi,'LineWidth',2)
hold
plot(stime,phi_aug,'r','LineWidth',2)
grid on
legend('Lat. Model','Aug. Lat. Model')
title('$\phi$ [deg]','interpreter','latex')

clc
disp('Pitch gain:')
disp(k_opt)
disp('Roll gain:')
disp(kp)
disp('Wash-out filter:')
evalc('washout_filter')
disp('Yaw gain')
disp(kr)

% Variables saving

reply = input('Do you want to save the SAS system? Y/N [Y]: ', 's');
if isempty(reply)
    reply = 'Y';
end
if reply=='Y'
    disp('')
    disp('Saving variables in file SAS_system.mat')
    filename='SAS_system.mat';
    save(filename,'aug_longmod','elevtoalpha','utoq','utoq_fil','k_opt','aug_latmod','aug_latmod_wo','kp','washout_filter','kr','sys_opt')
    disp('Done')
else
    disp('SAS system not saved')
end
disp('')
disp('End')

