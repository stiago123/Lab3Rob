
%% LQR
clc, clear, close all
actuator = tf(50.3855,[1 50.3855]); % linear
act_ss = ss(actuator);
act_ss.InputName='Volt';
act_ss.OutputName='ang';
act_ss.StateName='npi';
%% Load model
load('../modelo_lin.mat')
% evalc linmodel
%% LONGITUDINAL
model = series([act_ss 0;0 0],longmod);
% Extract Variables
% A = [u w q theta Ze omega ? ?] x [u w q theta Ze omega ? ?]
A_l = model.A;
A_l(abs(A_l)<1e-10) = 0;

% B = [u w q theta Ze omega ? ?] x [elevator] 
B_l = model.B(:,1);
B_l(abs(B_l)<1e-10) = 0;

% C = [theta] x [u w q theta Ze omega ? ?]
C_l = model.C(4,:);
C_l(abs(C_l)<1e-10) = 0;

% D = [theta] x [elevator]
D_l = model.D(4,1);

% QR 
Q_l = 1e-5*diag([1 1 1 7e15 1 1 1]);
R_l = diag(3e10);

% K_l = [elevator] x [u w q theta Ze omega]
K_l = lqr(A_l,B_l,Q_l,R_l);

% f_l
f_l = 1/(C_l/(-A_l+B_l*K_l)*B_l);

% Inputs
Ref_l = 2;
CI_l = 10*rand(6,1);

% Bode
AA_l = A_l-B_l*K_l;
BB_l = B_l*f_l;
CC_l = C_l-D_l*K_l;
DD_l = D_l*f_l;

% figure()
% options = sigmaoptions;
% options.FreqUnits = 'Hz';
% sigma(ss(AA_l,BB_l,CC_l,DD_l,'outputName',{'theta'},'inputName',{'elevator'}),options)
% grid on
%% DIRECCIONAL
% Extract Variables
model = series([act_ss 0;0 act_ss],latmod);
% A = [v p r phi psi] x [v p r phi psi]
A_d = model.A;
A_d(abs(A_d)<1e-10) = 0;

% B = [v p r phi psi] x [aileron rudder] 
B_d = model.B;
B_d(abs(B_d)<1e-10) = 0;

% C = [phi psi] x [v p r phi psi]
C_d = model.C(4:5,:);
C_d(abs(C_d)<1e-10) = 0;

% D = [phi psi] x [aileron rudder]
D_d = model.D(4:5,:);

% QR 
Q_d = 1e-5*diag([1 1 1 8e12 8e12 1 1]);
R_d = 1e7*diag([1 1]);

% K_d = [aileron rudder] x [v p r phi psi]
K_d = lqr(A_d,B_d,Q_d,R_d);

% F
f_d = inv(C_d/(-A_d+B_d*K_d)*B_d);

% Inputs
Ref_d = [1 4]';
CI_d = 10*rand(5,2);

% Bode
AA_d = A_d-B_d*K_d;
BB_d = B_d*f_d;
CC_d = C_d-D_d*K_d;
DD_d = D_d*f_d;

% figure()
% options = sigmaoptions;
% options.FreqUnits = 'Hz';
% sigma(ss(AA_d,BB_d,CC_d,DD_d,'outputName',{'phi','psi'},'inputName',{'rudder','ailerons'}),options)
% grid on
%% LQR modelo total
% Extract Variables
m_act = [0 0 0 0 0 0 0 0;
         0 act_ss 0 0 0 0 0 0;
         0 0 act_ss 0 0 0 0 0;
         0 0 0 0 0 0 0 0 ;
         0 0 0 0 0 0 0 0 ;
         0 0 0 0 0 0 0 0 ;
         0 0 0 0 0 0 0 0 ;
         0 0 0 0 0 0 0 act_ss];
model = series(m_act,linmodel);
% A = [phi theta psi p q r v w Xe Ye Ze omega u] x [13]
A = model.A;
A(abs(A)<1e-10) = 0;

% B = [13] x [elevator rudder aileron] 
B = model.B(:,[2 3 8]);
B(abs(B)<1e-10) = 0;

% C = [phi theta psi] x [13]
C = model.C(5:7,:);
C(abs(C)<1e-10) = 0;

% D = [phi theta psi] x [elevator rudder aileron]
D = model.D(5:7,[2 3 8]);

K = zeros(3,16);
% Kd = [aileron rudder] x [v p r phi psi]
% K_l = [elevator] x[u w q theta Ze omega]
% K = [elevator rudder aileron] x [ phi theta  psi p  q  r  u  v  w  Xe  Ye  Ze omega]
K([3 2], [8 4 6 1 3 14 16]) = K_d;
K(1, [7 9 5 2 12 13 15]) = K_l;

F = zeros(3);
% Fd = [aileron rudder] x [aileron rudder]
% Fl = [elevator] x[elevator]
% F = [elevator rudder aileron] x [ elevator rudder aileron]
F([3 2],[3 2]) = f_d;
F(1,1) = f_l;

Ref = 10*[1 2 3]';
CI = 10*rand(16,1);

% Bode
AA = A-B*K;
BB = B*F;
CC = C-D*K;
DD = D*F;

% figure()
% options = sigmaoptions;
% options.FreqUnits = 'Hz';
% sigma(ss(AA,BB,CC,DD,...
%          'outputName',{'phi','theta','psi'}, ...
%          'inputName',{'elevator','rudder','ailerons'}),...
%       options)
% grid on