clc, clear, close all
%% Load model
load('../modelo_lin.mat')
% evalc linmodel
model = longmod;
%% Numerical errors
model.A(abs(model.A)<1e-10)=0;
model.B(abs(model.B)<1e-10)=0;
model.C(abs(model.C)<1e-10)=0;
model.D(abs(model.D)<1e-10)=0;
%% Transfer matrix
actuator = tf(50.3855,[1 50.3855]); % linear
% g1 = theta/elevator
g1 = series(actuator,tf(model(4,1)));
% g2 = q/elevator
g2 = series(actuator,tf(model(3,1)));

G = [g1; g2]
%% SAS
figure()
rlocus(-G(2))
title('Rlocus SAS')
grid on

Kd = -0.059;
%% CAS
syms s Kp
g1s = poly2sym(cell2mat(g1.Numerator),s)/poly2sym(cell2mat(g1.Denominator),s);
g2s = poly2sym(cell2mat(g2.Numerator),s)/poly2sym(cell2mat(g2.Denominator),s);
Ki = -7;

C = Kp + Ki/s;
T = simplify(g1s/(1+Kd*g2s));

Go = simplify((C*T)/(1+C*T));
[~,Delta] = numden(Go);

[N, D] = numden(-1/solve(Delta==0, Kp));
N = sym2poly(N);
D = sym2poly(D);

Gaux = minreal(tf(N, D));

figure()
rlocus(-Gaux)
title('Rlocus comp. G_{aux}')
grid on

Kp = -3.31;%0.644;
%% Finish
s = tf('s');
C = Ki/s+Kp;
T = g1/(1+Kd*g2);

Go =minreal(T*C/(1+T*C));

figure()
options = sigmaoptions;
options.FreqUnits = 'Hz';
sigma(Go,options)
grid on
