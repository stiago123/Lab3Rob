%% LATERAL (Yaw o psi)
%% Load model
load('../modelo_lin.mat')
% evalc linmodel
model = latmod
%% Approx
model.A(abs(model.A)<1e-6)=0;
model.B(abs(model.B)<1e-6)=0;
model.C(abs(model.C)<1e-6)=0;
model.D(abs(model.D)<1e-6)=0;

%% Transfer matrix
% g1 = psi/aileron
g1_y = tf(model(5,1));
% g2 = r/aileron
g2_y = tf(model(3,1));
G_y = [g1_y; g2_y]

%% SAS
figure()
rlocus(G_y(2))
grid on

Kd_y = 0.059;

%% CAS
syms s Kp_y
g1s_y = poly2sym(cell2mat(g1_y.Numerator),s)/poly2sym(cell2mat(g1_y.Denominator),s);
g2s_y = poly2sym(cell2mat(g2_y.Numerator),s)/poly2sym(cell2mat(g2_y.Denominator),s);
Ki_y = 0.00001;

C_y = Kp_y + Ki_y/s;
T_y = simplify(g1s_y/(1+Kd_y*g2s_y));

Go_y = simplify((C_y*T_y)/(1+C_y*T_y));
[Num_y,Delta_y] = numden(Go_y);

[N_y, D_y] = numden(-1/solve(Delta_y==0, Kp_y));
N_y = sym2poly(N_y);
D_r = sym2poly(D_r);

Gaux_y = minreal(tf(N_y, Dy))

figure()
rlocus(Gaux_y)
title('Rlocus G_{aux} del Yaw/Aileron')
grid on

Kp = 0.06;

Go_y=subs(Go_y,Kp_y,0.06)
[No_y, Do_y] = numden(Go_y);
No_y = sym2poly(No_y);
Do_y = sym2poly(Do_y);
G_o_y = minreal(tf(No_y, Do_y))
bode(G_o_y)
grid on