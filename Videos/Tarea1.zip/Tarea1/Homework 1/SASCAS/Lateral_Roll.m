%% LATERAL (Roll o phi)
%% Load model
load('../modelo_lin.mat')
% evalc linmodel
model = latmod
%% Approx
model.A(abs(model.A)<1e-6)=0;
model.B(abs(model.B)<1e-6)=0;
model.C(abs(model.C)<1e-6)=0;
model.D(abs(model.D)<1e-6)=0;

%% Transfer matrix
% g1 = phi/rudder
g1_r = tf(model(4,2));
% g2 = p/rudder
g2_r = tf(model(2,2));
G_r = [g1_r; g2_r]

%% SAS
figure()
rlocus(G_r(2))
grid on

Kd_r = 0.0560;

%% CAS
syms s Kp_r
g1s_r = poly2sym(cell2mat(g1_r.Numerator),s)/poly2sym(cell2mat(g1_r.Denominator),s);
g2s_r = poly2sym(cell2mat(g2_r.Numerator),s)/poly2sym(cell2mat(g2_r.Denominator),s);
Ki_r = 0.00001;

C_r = Kp_r + Ki_r/s;
T_r = simplify(g1s_r/(1+Kd_r*g2s_r));

Go_r = simplify((C_r*T_r)/(1+C_r*T_r));
[Num_r,Delta_r] = numden(Go_r);

[N_r, D_r] = numden(-1/solve(Delta_r==0, Kp_r));
N_r = sym2poly(N_r);
D_r = sym2poly(D_r);

Gaux_r = minreal(tf(N_r, D_r))

figure()
rlocus(Gaux_r)
title('Rlocus G_{aux} del Roll/Rudder')
grid on

Kp = 0.06;

% Go_r=subs(Go_r,Kp_r,0.06)
% [No_r, Do_r] = numden(Go_r);
% No_r = sym2poly(No_r);
% Do_r = sym2poly(Do_r);
% G_o_r = minreal(tf(No_r, Do_r))
% bode(G_o_r)
% grid on
