clc, clear, close all
%% Load model
load('../modelo_lin.mat')
% evalc linmodel
model = longmod
%% Extract Variables
% A = [u w q theta Ze omega] x [u w q theta Ze omega]
A = model.A;
A(abs(A)<1e-10) = 0;

% B = [u w q theta Ze omega] x [elevator] 
B = model.B(:,1);
B(abs(B)<1e-10) = 0;

% C = [theta] x [u w q theta Ze omega]
C = model.C(4,:);
C(abs(C)<1e-10) = 0;

% D = [theta] x [elevator]
D = model.D(4,1);
%% LQR 
Q = diag([1e-4 1e-4 1e-4 4e8 1e-4 1e-4]);
R = diag(1);

[K,~,~] = lqr(A,B,Q,R); 
%% F
f = inv(C/(-A+B*K)*B);
%% Inputs
R = 30;
CI = 3*ones(6,1);
%% Bode
AA = A-B*K;
BB = B*f;
CC = C-D*K;
DD = D*f;

figure()
options = bodeoptions;
options.FreqUnits = 'Hz';
bode(ss(AA,BB,CC,DD,'outputName',{'theta'},'inputName',{'elevator'}),options)
grid on
