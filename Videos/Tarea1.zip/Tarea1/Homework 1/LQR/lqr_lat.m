clc, clear, close all
%% Load model
load('../modelo_lin.mat')
% evalc linmodel
model = latmod
%% Extract Variables
% A = [v p r phi psi] x [v p r phi psi]
A = model.A;
A(abs(A)<1e-10) = 0;

% B = [v p r phi psi] x [aileron rudder] 
B = model.B;
B(abs(B)<1e-10) = 0;

% C = [p r phi psi] x [v p r phi psi]
C = model.C(4:5,:);
C(abs(C)<1e-10) = 0;

% D = [p r phi psi] x [aileron rudder]
D = model.D(4:5,:);
%% LQR 
Q = diag([1 1 1 1e4 1e4]);
R = diag([1 1]);

[K,~,~] = lqr(A,B,Q,R); 
%% F
f = inv(C/(-A+B*K)*B);
%% Input
R = [1 4]';
CI = 3*ones(5,1);
%% Bode
AA = A-B*K;
BB = B*f;
CC = C-D*K;
DD = D*f;

figure()
options = bodeoptions;
options.FreqUnits = 'Hz';
bode(ss(AA,BB,CC,DD,'outputName',{'phi','psi'},'inputName',{'rudder','ailerons'}),options)
grid on